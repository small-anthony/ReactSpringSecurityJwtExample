package com.lacouf.rsbjwt.model;

import com.lacouf.rsbjwt.model.ENUM.StatutCandidature;
import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = {"etudiant_id", "offre_stage_id"}))
public class Candidature {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "etudiant_id")
    private Etudiant etudiant;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "offre_stage_id")
    private OffreStage offreStage;

    private LocalDateTime dateCandidature = LocalDateTime.now();

    @Enumerated(EnumType.STRING)
    private StatutCandidature statut = StatutCandidature.EN_ATTENTE_CONVOCATION;

    @Column(length = 1000)
    private String messageReponse;

    private LocalDateTime dateDecision;

    @OneToMany(mappedBy = "candidature", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("id ASC")
    private List<Convocation> convocations = new ArrayList<>();

    public Candidature() {}

    public Candidature(Etudiant etudiant, OffreStage offreStage) {
        this.etudiant = etudiant;
        this.offreStage = offreStage;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Etudiant getEtudiant() { return etudiant; }
    public Employeur getEmployeur() { return offreStage.getEmployeur(); }
    public OffreStage getOffreStage() { return offreStage; }
    public LocalDateTime getDateCandidature() { return dateCandidature; }
    public StatutCandidature getStatut() { return statut; }
    public void setStatut(StatutCandidature statut) { this.statut = statut; }

    public String getMessageReponse() { return messageReponse; }
    public void setMessageReponse(String messageReponse) { this.messageReponse = messageReponse; }

    public LocalDateTime getDateDecision() { return dateDecision; }
    public void setDateDecision(LocalDateTime dateDecision) { this.dateDecision = dateDecision; }

    public List<Convocation> getConvocations() {
        return convocations;
    }

    public void addConvocation(Convocation convocation) {
        convocation.setCandidature(this);
        convocations.add(convocation);
    }

    public String getTitreOffre() {
        return offreStage != null ? offreStage.getTitre() : null;
    }

    public String getNomEntreprise() {
        return offreStage != null ? offreStage.getNomEntreprise() : null;
    }

    public Integer getAnneeOffre() {
        return offreStage != null ? offreStage.getAnnee() : null;
    }

    public String getSalaireOffre() {
        return offreStage != null ? offreStage.getSalaire() : null;
    }

    public String getAdresseOffre() {
        return offreStage != null ? offreStage.getAdresse() : null;
    }

    public String telephoneLieuStage() {
        String telephoneOffre = offreStage != null ? offreStage.getTelephone() : null;
        if (telephoneOffre != null && !telephoneOffre.isBlank()) {
            return telephoneOffre;
        }
        return telephoneEmployeur();
    }

    public String nomContactEmployeur() {
        Employeur employeur = offreStage != null ? offreStage.getEmployeur() : null;
        return employeur != null ? employeur.nomComplet() : null;
    }

    public String telephoneEmployeur() {
        Employeur employeur = offreStage != null ? offreStage.getEmployeur() : null;
        return employeur != null ? employeur.getTelephone() : null;
    }

    public String emailEmployeur() {
        Employeur employeur = offreStage != null ? offreStage.getEmployeur() : null;
        return employeur != null ? employeur.getEmail() : null;
    }

    public Optional<Convocation> derniereConvocation() {
        if (convocations == null || convocations.isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(convocations.get(convocations.size() - 1));
    }

    public boolean appartientAEmployeur(String courriel) {
        return getEmployeur().aPourCourriel(courriel);
    }

    public boolean appartientAEtudiant(String courriel) {
        return etudiant.aPourCourriel(courriel);
    }

    public String getDescriptionOffre() {
        return offreStage.getDescription();
    }
}