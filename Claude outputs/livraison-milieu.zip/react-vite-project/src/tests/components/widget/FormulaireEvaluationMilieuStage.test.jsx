import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import "@testing-library/jest-dom/vitest";
import FormulaireEvaluationMilieuStage from "../../../components/widget/FormulaireEvaluationMilieuStage.jsx";
import { AuthServiceContext } from "../../../services/AuthService.tsx";
import * as ProfesseurService from "../../../services/api/ProfesseurService.js";
import i18n from "../../../../i18n.config.js";

vi.mock("../../../services/api/ProfesseurService.js");
vi.mock("../../../services/api/GestionnaireService.js");

const mockAuth = {
    buildAuthHeader: vi.fn(() => ({ Authorization: "Bearer token123" }))
};

const dossier = {
    etudiantId: 1,
    candidatureId: 3,
    contratId: 5,
    nomEntreprise: "CGI Inc.",
    personneContact: "Valentin Dimitrov",
    telephoneEntreprise: "438-555-0199",
    adresseEntreprise: "1350 boulevard René-Lévesque Ouest, Montréal, QC H3G 1T4",
    emailEntreprise: "emp@test.com",
    nomStagiaire: "Sophie Martin",
    discipline: "info",
    titreOffre: "Développeur Web",
    dateDebut: "2026-05-18",
    dateFin: "2026-08-21",
    dateStage: "2026-05-18 → 2026-08-21",
    salaireHoraire: "24.00$/h",
    nomProfesseur: "Martin Tremblay",
    milieuEvalue: false,
    evaluationMilieuId: null
};

describe("FormulaireEvaluationMilieuStage - préremplissage depuis l'offre", () => {
    beforeEach(() => {
        vi.clearAllMocks();
        i18n.changeLanguage("fr");
    });

    const renderForm = () =>
        render(
            <MemoryRouter>
                <AuthServiceContext.Provider value={mockAuth}>
                    <FormulaireEvaluationMilieuStage etudiantId={1} />
                </AuthServiceContext.Provider>
            </MemoryRouter>
        );

    it("devrait préremplir l'adresse et le téléphone avec ceux de l'offre", async () => {
        ProfesseurService.getDossierStage.mockResolvedValueOnce(dossier);

        renderForm();

        await waitFor(() => {
            expect(document.getElementById("adresse-entreprise")).toHaveValue(
                "1350 boulevard René-Lévesque Ouest, Montréal, QC H3G 1T4"
            );
        });
        expect(document.getElementById("telephone-entreprise")).toHaveValue("438-555-0199");
    });

    it("devrait laisser l'adresse vide si l'offre n'en a pas (ancienne offre)", async () => {
        ProfesseurService.getDossierStage.mockResolvedValueOnce({ ...dossier, adresseEntreprise: null });

        renderForm();

        await waitFor(() => {
            expect(document.getElementById("telephone-entreprise")).toHaveValue("438-555-0199");
        });
        expect(document.getElementById("adresse-entreprise")).toHaveValue("");
    });
});
