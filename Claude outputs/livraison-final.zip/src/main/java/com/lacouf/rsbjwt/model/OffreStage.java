package com.lacouf.rsbjwt.model;

import com.lacouf.rsbjwt.model.ENUM.StatusAcceptation;
import com.lacouf.rsbjwt.util.AcademicSessionUtils;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
public class OffreStage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String titre;
    private String nomEntreprise;
    private String description;
    private String discipline;
    private String salaire;
    private String duree;
    private String exigences;
    private String adresse;
    private String ville;
    private String codePostal;
    private String telephone;
    private LocalDate dateSuppression = null;

    @Column(nullable = false)
    private int annee = AcademicSessionUtils.getAnneeActuelle();

    @ManyToOne
    @JoinColumn(name = "employeur_id")
    private Employeur employeur;

    @ManyToMany(fetch = FetchType.LAZY)
    private List<Etudiant> etudiantsAutorises = new ArrayList<>();

    @Embedded
    private Approbation approbation = new Approbation();

    @OneToMany(mappedBy = "offreStage", fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    private final List<Candidature> candidatures = new ArrayList<>();



    public OffreStage() {}

    public OffreStage(String titre, String description, String nomEntreprise) {
        this.titre = titre;
        this.description = description;
        this.nomEntreprise = nomEntreprise;
        this.etudiantsAutorises = new ArrayList<>();
    }

    public OffreStage(String titre, String description, String nomEntreprise, String discipline, String salaire,
            String duree, String exigences) {
        this.titre = titre;
        this.description = description;
        this.nomEntreprise = nomEntreprise;
        this.discipline = discipline;
        this.salaire = salaire;
        this.duree = duree;
        this.exigences = exigences;
        this.etudiantsAutorises = new ArrayList<>();
    }

    public OffreStage(String titre, String description, String nomEntreprise,String discipline, String salaire,
                      String duree, String exigences, int annee) {
        this.titre = titre;
        this.description = description;
        this.nomEntreprise = nomEntreprise;
        this.discipline = discipline;
        this.salaire = salaire;
        this.duree = duree;
        this.exigences = exigences;
        this.annee = annee;
    }

    public OffreStage(String titre, String description, Employeur employeur,
            String discipline, String salaire, String duree, String exigences) {
        this.titre = titre;
        this.description = description;
        this.employeur = employeur;
        this.discipline = discipline;
        this.salaire = salaire;
        this.duree = duree;
        this.exigences = exigences;
        this.etudiantsAutorises = new ArrayList<>();
    }

    public void accepter() {
        this.approbation.accepter();
    }

    public void refuser(String message) {
        this.approbation.refuser(message);
    }

    public void attribuerVisibilite(List<Etudiant> etudiants) {
        if (etudiants != null && !etudiants.isEmpty()) {
            this.etudiantsAutorises = etudiants;
        } else {
            this.etudiantsAutorises.clear();
        }
    }

    public void reinitialiserApprobation() {
        this.approbation.setStatus(StatusAcceptation.EN_ATTENTE);
        this.approbation.setMessageRefus(null);
    }

    public void addCandidature(Candidature candidature) {
        candidatures.add(candidature);
    }

    public boolean isEnAttente() {
        return this.approbation.getStatus() == StatusAcceptation.EN_ATTENTE;
    }

    public Long getId() {
        return id;
    }

    public String getTitre() {
        return titre;
    }

    public String getNomEntreprise() {
        return nomEntreprise;
    }

    public String getDescription() {
        return description;
    }

    public List<Candidature> getCandidatures() {
        return candidatures;
    }

    public List<Etudiant> getEtudiantsAutorises() {
        return etudiantsAutorises;
    }

    public StatusAcceptation getStatus() {
        return this.approbation.getStatus();
    }

    public LocalDate getDateSuppression() {
        return dateSuppression;
    }

    public String getMessageReponse() {
        return this.approbation.getMessageRefus();
    }

    public Employeur getEmployeur() {
        return employeur;
    }

    public String getDiscipline() {
        return discipline;
    }

    public String getSalaire() {
        return salaire;
    }

    public String getDuree() {
        return duree;
    }

    public String getExigences() {
        return exigences;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getVille() {
        return ville;
    }

    public String getCodePostal() {
        return codePostal;
    }

    public String getTelephone() {
        return telephone;
    }

    public int getAnnee() {
        return annee;
    }

    public void setEmployeur(Employeur employeur) {
        this.employeur = employeur;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setDiscipline(String discipline) {
        this.discipline = discipline;
    }

    public void setSalaire(String salaire) {
        this.salaire = salaire;
    }

    public void setDuree(String duree) {
        this.duree = duree;
    }

    public void setExigences(String exigences) {
        this.exigences = exigences;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public void setCodePostal(String codePostal) {
        this.codePostal = codePostal;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public void setTitre (String titre) {
        this.titre = titre;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setNomEntreprise(String nomEntreprise) {
        this.nomEntreprise = nomEntreprise;
    }

    public void setAnnee(int annee) {
        this.annee = annee;
    }
    public void setDateSuppression(LocalDate dateSuppression) {
        this.dateSuppression = dateSuppression;
    }

    public boolean isSupprime() {
        return this.dateSuppression != null;
    }
    public void supprimer() {
        this.dateSuppression = LocalDate.now();
    }
}
