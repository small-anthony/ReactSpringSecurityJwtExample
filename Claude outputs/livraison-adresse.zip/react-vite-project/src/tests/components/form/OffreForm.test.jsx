import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom/vitest";
import OffreForm from "../../../components/form/OffreForm.jsx";
import i18n from "../../../../i18n.config.js";

const valeursValides = {
    titre: "Développeur Web",
    nomEntreprise: "CGI",
    discipline: "Techniques de l'informatique",
    duree: "12 semaines",
    salaire: "25.00",
    exigences: "Connaissances en React",
    description: "Développement d'applications web avec React et Spring Boot.",
    adresse: "1350 boulevard René-Lévesque Ouest, Montréal, QC",
    telephone: "514-555-1234",
};

describe("OffreForm - adresse et téléphone", () => {
    const handleSubmit = vi.fn();

    beforeEach(() => {
        vi.clearAllMocks();
        i18n.changeLanguage("fr");
    });

    const renderForm = (initialValues) =>
        render(<OffreForm id="formTest" initialValues={initialValues} onSubmit={handleSubmit} />);

    const soumettre = () => fireEvent.submit(document.getElementById("formTest"));

    it("devrait afficher les champs adresse et téléphone", () => {
        renderForm({});

        expect(screen.getByPlaceholderText(/1350 boulevard/i)).toBeInTheDocument();
        expect(screen.getByPlaceholderText(/514-555-1234/)).toBeInTheDocument();
    });

    it("devrait afficher des erreurs si l'adresse et le téléphone sont vides", () => {
        renderForm({ ...valeursValides, adresse: "", telephone: "" });

        soumettre();

        expect(screen.getByText("L'adresse est obligatoire.")).toBeInTheDocument();
        expect(screen.getByText("Le téléphone est obligatoire.")).toBeInTheDocument();
        expect(handleSubmit).not.toHaveBeenCalled();
    });

    it("devrait refuser un numéro de téléphone invalide", () => {
        renderForm({ ...valeursValides, telephone: "abc" });

        soumettre();

        expect(screen.getByText(/numéro de téléphone invalide/i)).toBeInTheDocument();
        expect(handleSubmit).not.toHaveBeenCalled();
    });

    it("devrait refuser un numéro de téléphone trop court", () => {
        renderForm({ ...valeursValides, telephone: "555-1234" });

        soumettre();

        expect(screen.getByText(/numéro de téléphone invalide/i)).toBeInTheDocument();
        expect(handleSubmit).not.toHaveBeenCalled();
    });

    it("devrait retirer l'erreur de l'adresse lorsque l'utilisateur la saisit", async () => {
        const user = userEvent.setup();
        renderForm({ ...valeursValides, adresse: "" });

        soumettre();
        expect(screen.getByText("L'adresse est obligatoire.")).toBeInTheDocument();

        await user.type(screen.getByPlaceholderText(/1350 boulevard/i), "1 rue Test, Montréal");

        expect(screen.queryByText("L'adresse est obligatoire.")).not.toBeInTheDocument();
    });

    it("devrait soumettre l'adresse et le téléphone lorsque le formulaire est valide", () => {
        renderForm(valeursValides);

        soumettre();

        expect(handleSubmit).toHaveBeenCalledWith(
            expect.objectContaining({
                adresse: "1350 boulevard René-Lévesque Ouest, Montréal, QC",
                telephone: "514-555-1234",
            })
        );
    });
});
